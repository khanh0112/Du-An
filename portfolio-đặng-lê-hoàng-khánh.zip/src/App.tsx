/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Github, 
  Linkedin, 
  Mail, 
  ExternalLink, 
  Code2, 
  Database, 
  Cpu, 
  ChevronRight, 
  Download, 
  Menu, 
  X,
  MapPin,
  Calendar,
  Briefcase,
  Layers,
  Sparkles,
  Zap
} from 'lucide-react';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Giới thiệu', href: '#hero' },
    { name: 'Kỹ năng', href: '#skills' },
    { name: 'Kinh nghiệm', href: '#experience' },
    { name: 'Dự án', href: '#projects' },
    { name: 'Liên hệ', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-dark-bg/80 backdrop-blur-lg border-b border-white/5 py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-2xl font-display font-bold text-white tracking-tighter"
        >
          KLK<span className="text-neon-blue">.</span>
        </motion.div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link, i) => (
            <motion.a
              key={link.name}
              href={link.href}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="text-sm font-medium text-gray-400 hover:text-white transition-colors"
            >
              {link.name}
            </motion.a>
          ))}
          <motion.a
            href="#contact"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="px-5 py-2 rounded-full bg-neon-blue text-dark-bg font-bold text-sm hover:shadow-[0_0_15px_rgba(0,210,255,0.5)] transition-all"
          >
            Hợp tác ngay
          </motion.a>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-dark-card border-b border-white/5 overflow-hidden"
          >
            <div className="flex flex-col p-6 space-y-4">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="text-lg text-gray-400 hover:text-white"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const SectionHeading = ({ children, subtitle }: { children: React.ReactNode, subtitle?: string }) => (
  <div className="mb-12">
    {subtitle && <p className="text-neon-blue font-mono text-sm uppercase tracking-widest mb-2">{subtitle}</p>}
    <h2 className="text-3xl md:text-5xl font-bold">{children}</h2>
  </div>
);

const Hero = () => (
  <section id="hero" className="min-h-screen flex items-center pt-20 px-6 relative overflow-hidden">
    {/* Background Decorative Elements */}
    <div className="absolute top-1/4 -right-20 w-96 h-96 bg-neon-blue/10 rounded-full blur-[120px]" />
    <div className="absolute bottom-1/4 -left-20 w-96 h-96 bg-neon-purple/10 rounded-full blur-[120px]" />

    <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <span className="inline-block px-4 py-1.5 rounded-full bg-neon-blue/10 border border-neon-blue/20 text-neon-blue text-xs font-bold uppercase tracking-wider mb-6">
          Sẵn sàng cho những thử thách mới
        </span>
        <h1 className="text-5xl md:text-7xl mb-6 leading-[1.1]">
          Xin chào, Tôi là <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">
            Hoàng Khánh
          </span>
        </h1>
        <p className="text-xl text-gray-400 mb-10 max-w-lg leading-relaxed">
          Full-stack Developer tại Đại học Nam Cần Thơ (DNC). Đam mê xây dựng phần mềm tối ưu và tích hợp AI để giải quyết các bài toán thực tế.
        </p>

        <div className="flex flex-wrap gap-4">
          <motion.a
            href="#projects"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 rounded-xl bg-neon-blue text-dark-bg font-bold flex items-center gap-2 hover:shadow-[0_0_20px_rgba(0,210,255,0.4)] transition-all"
          >
            Xem Dự Án <ChevronRight size={20} />
          </motion.a>
          <motion.a
            href="/cv.pdf"
            target="_blank"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 rounded-xl border border-white/10 hover:bg-white/5 font-bold flex items-center gap-2 transition-all"
          >
            Tải CV (PDF) <Download size={20} />
          </motion.a>
        </div>

        <div className="mt-12 flex items-center gap-6">
          <a href="#" className="text-gray-500 hover:text-white transition-colors"><Github size={24} /></a>
          <a href="#" className="text-gray-500 hover:text-white transition-colors"><Linkedin size={24} /></a>
          <a href="#" className="text-gray-500 hover:text-white transition-colors"><Mail size={24} /></a>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 0.2 }}
        className="relative flex justify-center"
      >
        <div className="relative w-[300px] h-[300px] md:w-[450px] md:h-[450px]">
          {/* Animated rings */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border-2 border-dashed border-neon-blue/20 rounded-full" 
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
            className="absolute inset-4 border border-neon-purple/20 rounded-full" 
          />
          
          <div className="absolute inset-8 rounded-full overflow-hidden border-4 border-dark-card shadow-[0_0_50px_rgba(0,210,255,0.3)]">
            <img 
              src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=1000&auto=format&fit=crop" 
              alt="Đặng Lê Hoàng Khánh" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          
          {/* Tech Badges floating */}
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="absolute -top-4 right-10 glass-card p-3 shadow-xl"
          >
            <Code2 size={24} className="text-neon-blue" />
          </motion.div>
          <motion.div 
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 5, repeat: Infinity }}
            className="absolute bottom-10 -left-4 glass-card p-3 shadow-xl"
          >
            <Sparkles size={24} className="text-neon-purple" />
          </motion.div>
        </div>
      </motion.div>
    </div>
  </section>
);

const Skills = () => {
  const skillGroups = [
    {
      title: "Frontend",
      skills: ["Next.js", "React", "Tailwind CSS", "Figma"],
      icon: <Layers size={20} className="text-neon-blue" />
    },
    {
      title: "Backend & App",
      skills: ["C# WinForms", "Java (Android)", "Firebase"],
      icon: <Database size={20} className="text-neon-purple" />
    },
    {
      title: "Tools & AI",
      skills: ["GitHub Copilot", "Genetic Algorithm", "A* Search"],
      icon: <Cpu size={20} className="text-neon-blue" />
    }
  ];

  return (
    <section id="skills" className="py-24 px-6 bg-white/[0.02]">
      <div className="max-w-7xl mx-auto">
        <SectionHeading subtitle="Tech Stack">Năng Lực Chuyên Môn</SectionHeading>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {skillGroups.map((group, idx) => (
            <motion.div
              key={group.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="glass-card p-8 neon-border"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 rounded-lg bg-white/5">{group.icon}</div>
                <h3 className="text-xl">{group.title}</h3>
              </div>
              <div className="flex flex-wrap gap-3">
                {group.skills.map((skill) => (
                  <span key={skill} className="px-4 py-2 rounded-lg bg-white/5 border border-white/5 text-sm font-medium hover:border-neon-blue/30 hover:text-white transition-all cursor-default">
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Experience = () => (
  <section id="experience" className="py-24 px-6">
    <div className="max-w-7xl mx-auto">
      <SectionHeading subtitle="Timeline">Kinh Nghiệm Làm Việc</SectionHeading>
      
      <div className="relative pl-8 border-l-2 border-white/5 space-y-12">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="absolute -left-[41px] top-0 w-4 h-4 rounded-full bg-neon-blue shadow-[0_0_10px_rgba(0,210,255,0.8)]" />
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
            <h3 className="text-2xl font-bold text-white">Founder / Chủ doanh nghiệp</h3>
            <span className="text-neon-blue font-mono text-sm mt-2 md:mt-0 px-3 py-1 rounded bg-neon-blue/10 border border-neon-blue/20">
              03/2026 - Hiện tại
            </span>
          </div>
          <p className="text-lg text-white/80 mb-2">Hộ kinh doanh Hỏa Hợp</p>
          <p className="text-gray-400 leading-relaxed max-w-2xl">
            Điều hành và quản lý hoạt động kinh doanh, ứng dụng công nghệ vào quy trình vận hành và quản lý để tối ưu hóa hiệu suất làm việc.
          </p>
        </motion.div>
      </div>
    </div>
  </section>
);

const Projects = () => {
  const projects = [
    {
      title: "Hệ thống Quản lý Kho Bia",
      desc: "Web app tối ưu quản lý kho sử dụng thuật toán FIFO. Theo dõi lô hàng, hạn sử dụng và báo cáo tồn kho thời gian thực.",
      tags: ["Next.js", "Firebase", "Algorithmic Logic"],
      tech: "Sử dụng Next.js & Firebase"
    },
    {
      title: "Ứng dụng Trắc nghiệm Thông minh",
      desc: "Nền tảng học tập với tính năng Smart Review và AI Generator – tự động tạo câu hỏi dựa trên lỗ hổng kiến thức của người dùng.",
      tags: ["AI Implementation", "React", "Node.js"],
      tech: "Tích hợp AI Generator"
    },
    {
      title: "Phần mềm Quản lý Điện",
      desc: "Ứng dụng chuyên dụng cho việc tính toán tiền điện bậc thang phức tạp, quản lý chỉ số và in hóa đơn tự động.",
      tags: ["C# WinForms", "SQL", "Professional Logic"],
      tech: "Logic tính toán bậc thang"
    },
    {
      title: "Chiến lược Marketing AI",
      desc: "Hệ thống phân tích và tối ưu hóa quy trình tiếp thị kỹ thuật số bằng cách khai thác sức mạnh của Gemini AI.",
      tags: ["Gemini AI", "Marketing Tech", "Automation"],
      tech: "Gemini AI Driven"
    }
  ];

  return (
    <section id="projects" className="py-24 px-6 bg-white/[0.02]">
      <div className="max-w-7xl mx-auto">
        <SectionHeading subtitle="Portfolio">Dự Án Tiêu Biểu</SectionHeading>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, idx) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ y: -10 }}
              className="glass-card overflow-hidden group"
            >
              <div className="h-48 bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 flex items-center justify-center relative">
                <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
                <Code2 size={64} className="text-white/20 group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute top-4 right-4 flex gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500"></div>
                  <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                </div>
              </div>
              <div className="p-8">
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map(tag => (
                    <span key={tag} className="text-[10px] font-bold uppercase tracking-wider text-neon-blue border border-neon-blue/30 px-2 py-0.5 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
                <h3 className="text-2xl font-bold mb-4 group-hover:text-neon-blue transition-colors">{project.title}</h3>
                <p className="text-gray-400 mb-6 line-clamp-3">
                  {project.desc}
                </p>
                <div className="flex items-center justify-between mt-auto">
                  <span className="text-sm font-mono text-gray-500">{project.tech}</span>
                  <button className="p-2 rounded-full bg-white/5 hover:bg-neon-blue hover:text-dark-bg transition-all">
                    <ExternalLink size={18} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => (
  <section id="contact" className="py-24 px-6 relative overflow-hidden">
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neon-blue/5 rounded-full blur-[150px] -z-10" />
    
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-16">
        <SectionHeading subtitle="Get in touch">Liên Hệ Hợp Tác</SectionHeading>
        <p className="text-gray-400 mt-4">Bạn có dự án thú vị? Đừng ngần ngại liên hệ với tôi để cùng tạo ra những giải pháp đột phá.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="glass-card p-6 flex flex-col items-center text-center">
          <div className="w-12 h-12 rounded-xl bg-neon-blue/10 flex items-center justify-center mb-4">
            <Mail className="text-neon-blue" />
          </div>
          <h4 className="font-bold mb-1">Email</h4>
          <p className="text-sm text-gray-400">khanhkhanh@mail.com</p>
        </div>
        <div className="glass-card p-6 flex flex-col items-center text-center">
          <div className="w-12 h-12 rounded-xl bg-neon-purple/10 flex items-center justify-center mb-4">
            <MapPin className="text-neon-purple" />
          </div>
          <h4 className="font-bold mb-1">Địa điểm</h4>
          <p className="text-sm text-gray-400">Cần Thơ, Việt Nam</p>
        </div>
        <div className="glass-card p-6 flex flex-col items-center text-center">
          <div className="w-12 h-12 rounded-xl bg-neon-blue/10 flex items-center justify-center mb-4">
            <Briefcase className="text-neon-blue" />
          </div>
          <h4 className="font-bold mb-1">Freelance</h4>
          <p className="text-sm text-gray-400">Đang sẵn sàng</p>
        </div>
      </div>

      <motion.form 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="glass-card p-8 md:p-12 space-y-6"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase text-gray-500 tracking-wider">Họ và tên</label>
            <input 
              type="text" 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-neon-blue transition-all"
              placeholder="Nhập tên của bạn..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase text-gray-500 tracking-wider">Địa chỉ Email</label>
            <input 
              type="email" 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-neon-blue transition-all"
              placeholder="email@vidu.com"
            />
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase text-gray-500 tracking-wider">Lời nhắn</label>
          <textarea 
            rows={5}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-neon-blue transition-all resize-none"
            placeholder="Bạn đang nghĩ gì?"
          />
        </div>
        <button className="w-full py-4 bg-neon-blue text-dark-bg font-bold rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_20px_rgba(0,210,255,0.4)] transition-all">
          Gửi tin nhắn <Zap size={20} fill="currentColor" />
        </button>
      </motion.form>
    </div>
  </section>
);

const Footer = () => (
  <footer className="py-12 border-t border-white/5 text-center">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-2xl font-display font-bold text-white mb-6">
        KLK<span className="text-neon-blue">.</span>
      </div>
      <p className="text-gray-500 text-sm mb-8 max-w-md mx-auto">
        Xây dựng tương lai kỹ thuật số với sự sáng tạo không ngừng và khát vọng chinh phục những đỉnh cao mới trong lập trình.
      </p>
      <div className="text-gray-600 text-xs font-mono uppercase tracking-[0.2em]">
        © 2026 ĐẶNG LÊ HOÀNG KHÁNH. ALL RIGHTS RESERVED.
      </div>
    </div>
  </footer>
);

// --- Main App ---

export default function App() {
  return (
    <div className="relative">
      <Navbar />
      <main>
        <Hero />
        <Skills />
        <Experience />
        <Projects />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

